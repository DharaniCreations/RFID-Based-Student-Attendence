// HTTPSRedirect Configuration file
// Fill in your Wifi network credentials
#ifndef HTTPSREDIRECT_CONFIG
#define HTTPSREDIRECT_CONFIG
const char* ssid = "";
const char* password = "";

const char* host = "script.google.com";
// Replace this with your own Google Sheets
// script-id to make server side changes
const char *GScriptId = "AKfycbzYw5G-oxvnwHpAJfDsS0PWNrO0KTBMiCW78lHUcEO6ZnFHvSw";

#endif